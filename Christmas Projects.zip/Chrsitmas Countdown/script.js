var targetDate = new Date("12/25/"+ new Date().getFullYear());
var sec = true;
var string;
var secondsNumber;
var minutesNumber;
var hoursNumber;
var daysNumber;
var seconds;
var minutes;
var hours;
var days;

function calculate()
{
	var rawCountdownNumber = targetDate.getTime() - new Date().getTime();
	
	if (rawCountdownNumber <= 1000){
		rawCountdownNumber = 0;
		document.getElementById("countdownHTML").innerHTML = "Merry Christmas!";
		return;
	}

	secondsNumber = (rawCountdownNumber / 1000) >> 0;
	minutesNumber = (secondsNumber / 60) >> 0;
	hoursNumber = (minutesNumber / 60) >> 0;
	daysNumber = (hoursNumber / 24) >> 0;
	secondsNumber = secondsNumber % 60;
	minutesNumber = minutesNumber % 60;
	hoursNumber = hoursNumber % 24;
	seconds = ", " + secondsNumber + " sec<br>";
	minutes = minutesNumber + " min";
	hours = hoursNumber + " hours,<br>";
	days = daysNumber + " days, ";
	

	if(hoursNumber == 1){
		hours = hoursNumber + " hour,<br>";
	}

	if(daysNumber == 1){
		days = daysNumber + " day, ";
	}

	if(sec == true){
		string = days + hours + minutes + seconds;
	}else{
		string = days + hours + minutes;
	}
	
	document.getElementById("countdownHTML").innerHTML = string + "Till Christmas";

}
calculate();
setInterval(calculate, 1000); 