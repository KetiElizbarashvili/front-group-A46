var movieList = ['Christmas Inheritance','The Christmas Chronicles','How the Grinch Stole Christmas','A Christmas Prince','The Holiday Calendar','Christmas With a View','Christmas in the Smokies','48 Christmas Wishes','A Holiday Engagement','The Spirit of Christmas','You Can'+"’"+'t Fight Christmas','Merry Kissmas','Dear Santa','Mickey'+"’"+'s Once Upon a Christmas','Christmas Crush','The Christmas Project','Beethoven'+"’"+'s Christmas Adventure','The Search for Santa Paws','Coffee Shop','Angela'+"’"+'s Christmas','A Christmas Prince - The Royal Wedding','Christmas Wedding Planner','A Dogwalker'+"’"+'s Christmas Tale','Santa Claws','Angels in the Snow','Miss Me This Christmas','Christmas Ranch','Mickey'+"’"+'s Twice Upon a Christmas','Get Santa','White Christmas','Holiday Baggage','How Sarah Got Her Wings','Santa Buddies','Love Actually','Mickey'+"’"+'s Magical Christmas','Holiday Breakup','A Christmas Star','Santa Paws 2','Believe','The Christmas Candle','Gnome Alone','Curious George, A Very Monkey Christmas','The Nutcracker','The Magic Snowflake','A Very Merry Christmas'];
var usedMovies = [];
var movieNum;
$(document).ready(function(){
  movieNum = Math.floor(Math.random() * movieList.length) + 1;
  $('h1').text(movieList[movieNum]);
  usedMovies.push(movieList[movieNum]);
  movieList.splice(movieNum,1);
});
$('p.a').click(function(){
  
  $('h1').css('opacity','0');
  
  movieNum = Math.floor(Math.random() * movieList.length) + 1;
  
  var movieText = movieList[movieNum];
  usedMovies.push(movieList[movieNum]);
  movieList.splice(movieNum,1);
  
  setTimeout(function(){
    
     if(movieList.length > 1){
       $('h1').text(movieText);
       $('h1').css('opacity','1');
     }
     else{
       alert('dumping');
       movieList = usedMovies.filter(Boolean);
       usedMovies = [];
       $('h1').text(movieText);
       $('h1').css('opacity','1');
     }
   },1000);
}); 